OneMoreMile restrained SE pack
WAV / mono / 22.05 kHz

01_attack_hit.wav
02_player_damage.wav
03_enemy_defeat.wav
04_player_death.wav
05_landing.wav

Designed to be restrained: short, relatively dark, and quieter than arcade-style effects.
Suggested Unity starting volume:
Hit 0.55 / Damage 0.65 / Defeat 0.60 / Death 0.70 / Landing 0.40
